package com.example.assignmet.Data

data class ItemPoolsR(
    val done: Boolean,
    val records: List<RecordXXX>,
    val totalSize: Int
)