package com.example.assignmet.Data

data class ItemType(
    val BL_Fee_Amount: Double,
    val BL_Fee_Percentage: Double,
    val ItemType: String,
    val ItemType_Id: String,
    val currencyid: String
)