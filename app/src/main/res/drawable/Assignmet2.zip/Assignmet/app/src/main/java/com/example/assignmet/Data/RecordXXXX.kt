package com.example.assignmet.Data

data class RecordXXXX(
    val Column_Name__c: String,
    val Event__c: String,
    val Id: String,
    val Include_URL__c: Boolean,
    val Included__c: Boolean,
    val Label_Name__c: String,
    val Name: String,
    val Setting_Type__c: String,
    val Table_Name__c: String,
    val attributes: Attributes
)