package com.example.assignmet.Data

data class BLNCountryR(
    val Id: String,
    val Long_Name__c: String,
    val Name: String,
    val Short_Name__c: String,
    val attributes: Attributes
)