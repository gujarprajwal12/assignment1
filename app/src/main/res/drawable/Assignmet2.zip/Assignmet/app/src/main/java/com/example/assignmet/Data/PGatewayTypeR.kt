package com.example.assignmet.Data

data class PGatewayTypeR(
    val Id: String,
    val Name: String,
    val attributes: Attributes
)