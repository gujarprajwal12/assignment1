package com.example.assignmet.Data

data class Profile(
    val Profile: ProfileX,
    val Userid: String,
    val designation: Any,
    val profileCity: String,
    val profilecountry: String,
    val profileimage: String,
    val profilestate: String
)