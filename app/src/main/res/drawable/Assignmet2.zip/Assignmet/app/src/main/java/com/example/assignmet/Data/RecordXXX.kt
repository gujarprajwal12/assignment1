package com.example.assignmet.Data

data class RecordXXX(
    val Event__c: String,
    val Id: String,
    val Item_Type__c: String,
    val attributes: Attributes
)