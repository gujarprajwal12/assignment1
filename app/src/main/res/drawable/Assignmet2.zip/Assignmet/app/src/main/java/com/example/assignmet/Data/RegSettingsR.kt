package com.example.assignmet.Data

data class RegSettingsR(
    val done: Boolean,
    val records: List<RecordXXXX>,
    val totalSize: Int
)