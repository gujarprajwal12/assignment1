package com.example.assignmet.Data

data class BlnCustomFieldsR(
    val Id: String,
    val attributes: Attributes
)