package com.example.assignmet.Data

data class DefaultCompanyIDR(
    val Id: String,
    val Name: String,
    val attributes: Attributes
)