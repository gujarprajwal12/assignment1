package com.example.assignmet.Data

data class Attributes(
    val type: String,
    val url: String
)