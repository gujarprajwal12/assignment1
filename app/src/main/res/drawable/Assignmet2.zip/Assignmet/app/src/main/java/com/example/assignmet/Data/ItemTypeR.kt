package com.example.assignmet.Data

data class ItemTypeR(
    val Eventdex_Product__c: Boolean,
    val Id: String,
    val attributes: Attributes
)