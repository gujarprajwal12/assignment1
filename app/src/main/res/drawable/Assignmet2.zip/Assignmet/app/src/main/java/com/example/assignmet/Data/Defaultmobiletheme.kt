package com.example.assignmet.Data

data class Defaultmobiletheme(
    val BLN_Events__c: String,
    val Dashboard_BG_Color__c: String,
    val Dashboard_Background__c: String,
    val Event_Bar_Back_Color__c: String,
    val Event_Bar_Fore_Color__c: String,
    val Id: String,
    val IsDefaultTheme__c: Boolean,
    val Nav_Bar_Color__c: String,
    val Product_Placement__c: String,
    val Side_Menu_BG_Color_Transparency__c: String,
    val Side_Menu_Background_Color__c: String,
    val Side_Menu_Background_Image__c: String,
    val Tile_Block_Color__c: String,
    val Tile_Icon_Color__c: String,
    val Tile_Label_Font_Color__c: String,
    val Tile_Shapes_Color__c: String,
    val Tile_Shapes_Image__c: String,
    val Tiles_BG_Color__c: String,
    val Tiles_BG_Transparency__c: String,
    val attributes: Attributes
)