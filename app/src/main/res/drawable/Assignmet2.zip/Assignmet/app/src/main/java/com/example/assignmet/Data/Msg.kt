package com.example.assignmet.Data

data class Msg(
    val EventID: Any,
    val attconnectId: Any,
    val company: Any,
    val fromFullName: Any,
    val message: Any,
    val notificationType: Any,
    val requestfrom: Any,
    val requestto: Any,
    val senddt: Any,
    val status: Any,
    val titleStr: Any,
    val toFullName: Any,
    val validbadge: Any
)