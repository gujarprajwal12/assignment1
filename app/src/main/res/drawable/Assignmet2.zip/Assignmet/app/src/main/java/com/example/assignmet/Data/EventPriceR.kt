package com.example.assignmet.Data

data class EventPriceR(
    val done: Boolean,
    val records: List<RecordXX>,
    val totalSize: Int
)