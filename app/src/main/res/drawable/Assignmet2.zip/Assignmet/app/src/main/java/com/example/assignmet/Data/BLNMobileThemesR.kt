package com.example.assignmet.Data

data class BLNMobileThemesR(
    val done: Boolean,
    val records: List<Record>,
    val totalSize: Int
)