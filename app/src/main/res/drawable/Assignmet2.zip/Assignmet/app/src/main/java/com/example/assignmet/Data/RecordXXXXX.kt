package com.example.assignmet.Data

data class RecordXXXXX(
    val Company__c: String,
    val GN_User__c: String,
    val Id: String,
    val Name: String,
    val attributes: Attributes
)