package com.example.assignmet.Data

data class UCRoleR(
    val done: Boolean,
    val records: List<RecordXXXXX>,
    val totalSize: Int
)