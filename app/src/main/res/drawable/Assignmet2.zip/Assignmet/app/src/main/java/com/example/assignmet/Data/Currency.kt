package com.example.assignmet.Data

data class Currency(
    val Currency_Name__c: String,
    val Currency_Symbol__c: String,
    val Id: String,
    val Name: String,
    val attributes: Attributes
)