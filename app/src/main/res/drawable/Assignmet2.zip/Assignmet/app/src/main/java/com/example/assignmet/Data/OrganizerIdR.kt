package com.example.assignmet.Data

data class OrganizerIdR(
    val Id: String,
    val Name: String,
    val PG_Authorization_Key__c: String,
    val PG_Credit_Card_Overwrite__c: Boolean,
    val attributes: Attributes
)