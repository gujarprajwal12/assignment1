package com.example.assignmet.Data

data class HomeAddressR(
    val Id: String,
    val attributes: Attributes
)